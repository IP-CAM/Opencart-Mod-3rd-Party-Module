<?php

/*
@name     3rd Party|Voku|Html Min
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.0
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/mod-3rd-party
@licence  https://github.com/ocmod-space/mod-3rd-party/blob/main/LICENSE.txt
*/

class ControllerExtensionModuleHtmlMin extends Controller {
	private $mname = 'htmlmin';
	private $mtype = 'module';
	private $mroute;
	private $mmodel;
	private $module;

	private $error = [];

	public function __construct($params) {
		parent::__construct($params);

		$this->mroute = 'extension/' . $this->mtype . '/' . $this->mname;
		$this->mmodel = 'model_' . str_replace('/', '_', $this->mroute);
		$this->module = $this->mtype . '_' . $this->mname;
	}

	public function index() {
		$this->load->language($this->mroute);

		$this->document->setTitle($this->language->get('heading_title'));

		$token = 'user_token=' . $this->session->data['user_token'];
		$extension_route = 'marketplace/extension';

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $token, true),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link($extension_route, $token . '&type=' . $this->mtype, true),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link($this->mroute, $token, true),
		];

		$data['cancel'] = $this->url->link($extension_route, $token . '&type=' . $this->mtype, true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($this->mroute, $data));
	}

	public function install() {
		$this->uninstall();

		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->mroute);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->mroute);

		$event_route = 'setting/event';
		$event_model = 'model_setting_event';

		$this->load->model($event_route);

		$event = $this->mname . '_admin';

		$trigger = 'admin/view/design/layout_form/before';
		$action = $this->mroute . '/beforeViewDesignLayoutForm';
		$this->{$event_model}->addEvent($event, $trigger, $action);

		$this->config->set($this->module . '_status', '1');

		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->module, [
			$this->module . '_status' => 1,
		]);

		if (!is_dir(DIR_STORAGE . 'vendor/voku')) {
			rename(DIR_SYSTEM . 'library/voku', DIR_STORAGE . 'vendor/voku');
		}
	}

	public function uninstall() {
		$event_route = 'setting/event';
		$event_model = 'model_setting_event';
		$delete_method = 'deleteEventByCode';

		$this->load->model($event_route);

		$events = [
			$this->mname . '_admin',
			$this->mname . '_catalog',
		];

		// Delete events
		foreach ($events as $event) {
			$this->{$event_model}->{$delete_method}($event);
		}

		if (is_dir(DIR_STORAGE . 'vendor/voku')) {
			rename(DIR_STORAGE . 'vendor/voku', DIR_SYSTEM . 'library/voku');
		}

		$this->load->model('user/user_group');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', $this->mroute);
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', $this->mroute);
	}

	// https://forum.opencart.com/viewtopic.php?p=799279#p799279
	// admin/view/design/layout_form/before
	public function beforeViewDesignLayoutForm(&$route, &$data) {
		foreach ($data['extensions'] as $key => $extension) {
			if ($extension['code'] == $this->mname) {
				unset($data['extensions'][$key]);
			}
		}

		return null;
	}

	protected function validate() {
		$this->load->model('user/user_group');

		if (!$this->user->hasPermission('modify', $this->mroute)) {
			$this->error['permission'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}
