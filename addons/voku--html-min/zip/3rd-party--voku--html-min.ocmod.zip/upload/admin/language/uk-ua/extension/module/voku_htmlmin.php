<?php

/*
@name     3rd Party|Voku|Html Min
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.0
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/mod-3rd-party
@licence  https://github.com/ocmod-space/mod-3rd-party/blob/main/LICENSE.txt
*/


$_['heading_title'] = '#ocmod.space: 3rd-party|voku|html-min';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів <b>3rd Party|Voku|Html Min</b>';
$_['text_made'] = 'Зроблено з <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> в Україні';
$_['text_about'] = 'Модуль інсталює теку <a target="_blank" href="https://github.com/voku/htmlmin">voku/htmlmin</a> - HTML мініфікатор.';
