# JSlite Docs

JSlite is a PHP based Javascript compiler designed for minification.

- [API Reference](api/readme.md)
