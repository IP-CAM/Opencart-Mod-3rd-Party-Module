<?php

/*
@name     3rd Party|Hexydec|Htmldoc
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.0
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/mod-3rd-party
@licence  https://github.com/ocmod-space/mod-3rd-party/blob/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: 3rd-party|hexydec|htmldoc';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>3rd Party|Hexydec|Htmldoc</b>';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> in Ukraine';
$_['text_about'] = 'The module installs a library <a target="_blank" href="https://github.com/hexydec/htmldoc">PHP HTML Document Parser and Minifier</a>.';
