<?php

/*
@name     3rd Party|Masterminds|Html5 Php
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.0
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/mod-3rd-party
@licence  https://github.com/ocmod-space/mod-3rd-party/blob/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: 3rd-party|masterminds|html5-php';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>3rd Party|Masterminds|Html5 Php</b>';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> in Ukraine';
$_['text_about'] = 'The module adds <a target="_blank" href="https://github.com/masterminds/html5-php">Masterminds</a> HTML5 parser to the OpenCart vendor library.';
